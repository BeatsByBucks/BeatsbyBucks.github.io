# HTML5AudioPlaylist
Simple code for making an HTML5 audio playlist. 

<p><b>Update - </b> Want more features including looping, shuffeling, and more? See <a href="https://github.com/TechTube/BetterAudioPlaylist">this repo</a> instead.</p>
<h3><a href="https://techtube.github.io/HTML5AudioPlaylist/">Demo</a></h3> <h3><a href="https://github.com/TechTube/HTML5AudioPlaylist/archive/master.zip">Download</a></h3>  <h3><a href="https://www.youtube.com/watch?v=vtZCMTtP-0Y">Installation instructions</a></h3> 
